/*
 *
 it.

c
 *
 *  Created on: 06-Jun-2021
 *      Author: Apoorv singh negi
 */
#include "main.h"
//handle the interrupt at IT.c
extern TIM_HandleTypeDef htimer2;
extern TIM_HandleTypeDef htimer6;


void SysTick_Handler (void)
{
	HAL_IncTick();
	HAL_SYSTICK_IRQHandler();
}

//when rising edge is detected than this interrupt handler is called to detect the cause of interrupt and handle it
void TIM2_IRQHandler(void)
{
	HAL_TIM_IRQHandler(&htimer2);//to handle interrupts of TIM2
}

//when reload value is reached interrupt is generated hence to handle that interrupt this function is called.
void TIM6_DAC_IRQHandler(void)
{
	HAL_GPIO_TogglePin(GPIOA,GPIO_PIN_5);//as the LED is in pin no 5 i.e. PA5 hence we have to toggle the LED
	HAL_TIM_IRQHandler(&htimer6);
}
