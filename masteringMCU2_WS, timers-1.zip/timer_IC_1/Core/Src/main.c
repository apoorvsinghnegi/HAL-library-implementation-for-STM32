//SECTION-9----> INPUT CAPTURE BLOCK USING LSE AND HSE AS INPUT CLOCK ON INPUT CHANNEL

#include <string.h>
#include "stm32f4xx_hal.h"
#include "main.h"

//void SystemClockConfig(uint8_t clock_freq);
void GPIO_Init(void);
void Error_handler(void);
void TIMER2_Init(void);
void TIMER6_Init(void);
void LSE_Configuration(void);
void UART2_Init(void);
void SystemClock_Config_HSE(uint8_t clock_freq);

TIM_HandleTypeDef htimer2;
TIM_HandleTypeDef htimer6;
UART_HandleTypeDef huart2;

uint32_t input_captures[2] = {0};
uint8_t count=1;
volatile uint8_t is_capture_done = FALSE;



int main(void)
{
	uint32_t capture_difference =0;
	double timer2_cnt_freq=0;
	double timer2_cnt_res=0;
	double user_signal_time_period =0;
	double user_signal_freq=0;
	char usr_msg[100];
	HAL_Init();

	//SystemClockConfig(SYS_CLOCK_FREQ_50_MHZ);

	SystemClock_Config_HSE(SYS_CLOCK_FREQ_50_MHZ);

	GPIO_Init();

	UART2_Init();

	TIMER6_Init();

	TIMER2_Init();

	LSE_Configuration();

    HAL_TIM_Base_Start_IT(&htimer6);//to start the timer as we have only intialized the timer but not started it

	HAL_TIM_IC_Start_IT(&htimer2,TIM_CHANNEL_1);//to start the timer as we have only intialized the timer but not started it


	while(1)
	{
		//now let's calculate the frequency of the input signal given in the input channel 1
		if(is_capture_done)
		{
			if(input_captures[1] > input_captures[0])
				capture_difference = input_captures[1] - input_captures[0];
			else
				capture_difference = (0XFFFFFFFF -input_captures[0]) + input_captures[1];

       //APB1 timer clock frequency = 2 * PCLK1--->see from clock configuration of the cubemx
		timer2_cnt_freq = (HAL_RCC_GetPCLK1Freq() * 2 ) / (htimer2.Init.Prescaler + 1);
		timer2_cnt_res = 1/ timer2_cnt_freq;
		user_signal_time_period = capture_difference * timer2_cnt_res;
		user_signal_freq = 1/user_signal_time_period ;

		sprintf(usr_msg,"Frequency of the signal applied = %.2f Hz\r\n",user_signal_freq );
		HAL_UART_Transmit(&huart2,(uint8_t*)usr_msg,strlen(usr_msg),HAL_MAX_DELAY);///to transmit msg to uart

		is_capture_done = FALSE;

		}

	}


	return 0;
}


/*void SystemClockConfig(uint8_t clock_freq )
{
	RCC_OscInitTypeDef Osc_Init;
	RCC_ClkInitTypeDef Clock_Init;

	Osc_Init.OscillatorType = RCC_OSCILLATORTYPE_HSI | RCC_OSCILLATORTYPE_LSE;//configure both LSI and HSI
	Osc_Init.HSIState = RCC_HSI_ON;
	Osc_Init.LSEState = RCC_LSE_ON;
	Osc_Init.HSICalibrationValue = 16;
	Osc_Init.PLL.PLLState = RCC_PLL_ON;
	Osc_Init.PLL.PLLSource = RCC_PLLSOURCE_HSI;

	switch(clock_freq)
	 {
	  case SYS_CLOCK_FREQ_50_MHZ:
		  Osc_Init.PLL.PLLM = 8;
		  Osc_Init.PLL.PLLN = 50;
		  Osc_Init.PLL.PLLP = RCC_PLLP_DIV2;
		  Osc_Init.PLL.PLLQ = 2;
		  Osc_Init.PLL.PLLR = 2;
		  Clock_Init.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
	                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
		  Clock_Init.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
		  Clock_Init.AHBCLKDivider = RCC_SYSCLK_DIV1;
		  Clock_Init.APB1CLKDivider = RCC_HCLK_DIV2;
		  Clock_Init.APB2CLKDivider = RCC_HCLK_DIV1;
	     break;

	  case SYS_CLOCK_FREQ_84_MHZ:
		  Osc_Init.PLL.PLLM = 8;
		  Osc_Init.PLL.PLLN = 84;
		  Osc_Init.PLL.PLLP = RCC_PLLP_DIV2;
		  Osc_Init.PLL.PLLQ = 2;
		  Osc_Init.PLL.PLLR = 2;
		  Clock_Init.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
	                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
		  Clock_Init.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
		  Clock_Init.AHBCLKDivider = RCC_SYSCLK_DIV1;
		  Clock_Init.APB1CLKDivider = RCC_HCLK_DIV2;
		  Clock_Init.APB2CLKDivider = RCC_HCLK_DIV1;
	     break;

	  case SYS_CLOCK_FREQ_120_MHZ:
		  Osc_Init.PLL.PLLM = 8;
		  Osc_Init.PLL.PLLN = 120;
		  Osc_Init.PLL.PLLP = RCC_PLLP_DIV2;
		  Osc_Init.PLL.PLLQ = 2;
		  Osc_Init.PLL.PLLR = 2;
		  Clock_Init.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
	                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
		  Clock_Init.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
		  Clock_Init.AHBCLKDivider = RCC_SYSCLK_DIV1;
		  Clock_Init.APB1CLKDivider = RCC_HCLK_DIV4;
		  Clock_Init.APB2CLKDivider = RCC_HCLK_DIV2;
	     break;

	  default:
	   return ;
	 }

		if (HAL_RCC_OscConfig(&Osc_Init) != HAL_OK)
	{
			Error_handler();
	}



	if (HAL_RCC_ClockConfig(&Clock_Init, FLASH_LATENCY_2) != HAL_OK)
	{
		Error_handler();
	}

*/
	/*Configure the systick timer interrupt frequency (for every 1 ms) */
//	uint32_t hclk_freq = HAL_RCC_GetHCLKFreq();
	//HAL_SYSTICK_Config(hclk_freq/1000);

	/**Configure the Systick
	*/
//	HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

	/* SysTick_IRQn interrupt configuration */
	//HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);

//}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config_HSE(uint8_t clock_freq)//system clock configuration for different oscillator types
{
	RCC_OscInitTypeDef Osc_Init;
	RCC_ClkInitTypeDef Clock_Init;
    uint8_t flash_latency=0;

	Osc_Init.OscillatorType = RCC_OSCILLATORTYPE_HSE | RCC_OSCILLATORTYPE_LSE | RCC_OSCILLATORTYPE_HSI ;
	//here, it means we are turning ON all HSE, HSI and LSE all together as if we do alag alag intialization
	//then overlapping is happening and it is not working properly.
	Osc_Init.HSEState = RCC_HSE_ON;
	Osc_Init.LSEState = RCC_LSE_ON;
	Osc_Init.HSIState = RCC_HSI_ON;
	Osc_Init.PLL.PLLState = RCC_PLL_ON;
	Osc_Init.PLL.PLLSource = RCC_PLLSOURCE_HSE;

	switch(clock_freq)
	 {
	  case SYS_CLOCK_FREQ_50_MHZ:
		  Osc_Init.PLL.PLLM = 4;
		  Osc_Init.PLL.PLLN = 50;
		  Osc_Init.PLL.PLLP = RCC_PLLP_DIV2;
		  Osc_Init.PLL.PLLQ = 2;
		  Osc_Init.PLL.PLLR = 2;
		  Clock_Init.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK // to enable all the clock sources and later enable the prescaler associated with them
	                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
		  Clock_Init.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
		  Clock_Init.AHBCLKDivider = RCC_SYSCLK_DIV1;
		  Clock_Init.APB1CLKDivider = RCC_HCLK_DIV2;
		  Clock_Init.APB2CLKDivider = RCC_HCLK_DIV1;
          flash_latency = 1;
	     break;

	  case SYS_CLOCK_FREQ_84_MHZ:
		  Osc_Init.PLL.PLLM = 4;
		  Osc_Init.PLL.PLLN = 84;
		  Osc_Init.PLL.PLLP = RCC_PLLP_DIV2;
		  Osc_Init.PLL.PLLQ = 2;
		  Osc_Init.PLL.PLLR = 2;
		  Clock_Init.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
	                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
		  Clock_Init.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
		  Clock_Init.AHBCLKDivider = RCC_SYSCLK_DIV1;
		  Clock_Init.APB1CLKDivider = RCC_HCLK_DIV2;
		  Clock_Init.APB2CLKDivider = RCC_HCLK_DIV1;
          flash_latency = 2;
	     break;

	  case SYS_CLOCK_FREQ_120_MHZ:
		  Osc_Init.PLL.PLLM = 4;
		  Osc_Init.PLL.PLLN = 120;
		  Osc_Init.PLL.PLLP = RCC_PLLP_DIV2;
		  Osc_Init.PLL.PLLQ = 2;
		  Osc_Init.PLL.PLLR = 2;
		  Clock_Init.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
	                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
		  Clock_Init.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
		  Clock_Init.AHBCLKDivider = RCC_SYSCLK_DIV1;
		  Clock_Init.APB1CLKDivider = RCC_HCLK_DIV4;
		  Clock_Init.APB2CLKDivider = RCC_HCLK_DIV2;
          flash_latency = 3;
	     break;

	  default:
	   return ;
	 }

		if (HAL_RCC_OscConfig(&Osc_Init) != HAL_OK)
	{
			Error_handler();
	}



	if (HAL_RCC_ClockConfig(&Clock_Init, flash_latency) != HAL_OK)
	{
		Error_handler();
	}


	/*Configure the systick timer interrupt frequency (for every 1 ms) */
	uint32_t hclk_freq = HAL_RCC_GetHCLKFreq();
	HAL_SYSTICK_Config(hclk_freq/1000);

	/**Configure the Systick
	*/
	HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK); //for cortex timer frequency as HCLK passes through a prescaler before reaching it

	/* SysTick_IRQn interrupt configuration */
	HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);



 }

void GPIO_Init(void)//to toggle LED, hence we are intializing GPIO here
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
	GPIO_InitTypeDef ledgpio;
	ledgpio.Pin = GPIO_PIN_5;
	ledgpio.Mode = GPIO_MODE_OUTPUT_PP;
	ledgpio.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOA,&ledgpio);//to intialize the GPIO with the given functionality defined
}


//to toggle LED at 50khz freq i.e. time period of 10microsec hence we adjust the value of period and prescaler
//according to it

//using this function to check whether we are able to toggle the LED at 50KHz which confirms we have generated 50khz wave
void TIMER6_Init(void)
{
	htimer6.Instance = TIM6;
	htimer6.Init.Prescaler = 9;
	htimer6.Init.Period = 50-1;
	if( HAL_TIM_Base_Init(&htimer6) != HAL_OK )
	{
		Error_handler();
	}

}


void UART2_Init(void)
{
	huart2.Instance = USART2;
	huart2.Init.BaudRate = 115200;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	if ( HAL_UART_Init(&huart2) != HAL_OK )
	{
		//There is a problem
		Error_handler();
	}


}


void TIMER2_Init(void)
{
	 TIM_IC_InitTypeDef timer2IC_Config;//to configure the input channel

	 //basic timer intialization must be done before configuring it as in the input capture mode

	 htimer2.Instance = TIM2;//TIMER 2 BASE ADDRESS
	 //BASIC TIMER INTIALIZATION IS ALSO REQUIRED AS TIMER WILL KEEP ON TICKING DURING THE PROCESS
	 htimer2.Init.CounterMode = TIM_COUNTERMODE_UP;//BY DEFAULT UP COUTING
	 htimer2.Init.Period = 0xFFFFFFFF;// WE WANT THE COUNTER TO RUN FOR MAXIMUM VALUE , IT IS 32 BIT COUNTER
	 htimer2.Init.Prescaler = 1;
	 if ( HAL_TIM_IC_Init(&htimer2) != HAL_OK)//as we want to configure timer in input capture mode hence, we use this different API
	 {
		 Error_handler();
	 }

	 timer2IC_Config.ICFilter = 0 ;//configure the input filter in the block diagram--> filter the input signal as it may have some errors,unstable
	 timer2IC_Config.ICPolarity = TIM_ICPOLARITY_RISING;//configure the edge detector of a particular channel block in the diagram of timer2
	                                                    // of a particular signal given as input from the input channel i.e whether rising edge, falling edge,etc
	 timer2IC_Config.ICPrescaler = TIM_ICPSC_DIV1;
	 timer2IC_Config.ICSelection = TIM_ICSELECTION_DIRECTTI;//selection means selection to input capture block-->
	 //if it comes from the same channel--> direct
	 //if it comes from some other channel-->indirect
	 //if it comes from slave mode controller--> TRC
	 if ( HAL_TIM_IC_ConfigChannel(&htimer2, &timer2IC_Config, TIM_CHANNEL_1) != HAL_OK)//we have been using first channel out of 4 channel of timer2
	 {
		 Error_handler();
	 }



}

void LSE_Configuration(void)//as by default the on-board LSE is turned OFF.
{

#if 0
	RCC_OscInitTypeDef Osc_Init;
	Osc_Init.OscillatorType = RCC_OSCILLATORTYPE_LSE;//we want to use LSE as our clock
	Osc_Init.LSEState = RCC_LSE_ON;// we have to make the state of LSE as ON
	if (HAL_RCC_OscConfig(&Osc_Init) != HAL_OK)
	{
		Error_handler();
	}
#endif

	HAL_RCC_MCOConfig(RCC_MCO1,RCC_MCO1SOURCE_HSI,RCC_MCODIV_4);//part1) was to make LSE output come over the GPIO pin -PA8 (MCO1 pin) of the micro-controller
	                                                            //36.8/4
	//part2)here we are making HSI output to come over GPIO pin--> hence, 16/4 = 4Mhz



}

//capture call back is used when rising edge of the clock is detected and due that capture interrupt is generated which is
//then passed to interrupt handler and then capture call back is called from that interrupt handler
 void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
#if 1
 if(! is_capture_done)
 {
	 if(count == 1)
	 {
		 input_captures[0] = __HAL_TIM_GET_COMPARE(htim, TIM_CHANNEL_1);//reads the CCR1 register contents
		 count++;
	 }
	 else if (count == 2)
	 {
		 input_captures[1] = __HAL_TIM_GET_COMPARE(htim, TIM_CHANNEL_1);
		 count =1;
		 is_capture_done = TRUE;
	 }

 }
#endif

}

void Error_handler(void)
{
	while(1);
}
