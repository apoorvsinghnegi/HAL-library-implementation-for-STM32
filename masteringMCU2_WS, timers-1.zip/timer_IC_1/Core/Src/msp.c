/*
 *

msp.c




 *
 *  Created on: 06-Jun-2021
 *      Author: Apoorv singh negi
 */

#include "main.h"
void HAL_MspInit(void)
{
	 //Here will do low level processor specific inits.
		//1. Set up the priority grouping of the arm cortex mx processor
		HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);//by default it would be set to 4, which has subpriority as zero

		//2. Enable the required system exceptions of the arm cortex mx processor
		SCB->SHCSR |= 0x7 << 16; //usage fault, memory fault and bus fault system exceptions enabled using system handle
		                        // control and state register

		//3. configure the priority for the system exceptions, //by default=0 i.e. highest
		//to configure check hal_cortex.c file as priority group is 4 so we have last argument in each case as 0.
		HAL_NVIC_SetPriority(MemoryManagement_IRQn,0,0);
		HAL_NVIC_SetPriority(BusFault_IRQn,0,0);
		HAL_NVIC_SetPriority(UsageFault_IRQn,0,0);

}
//this function is called by "HAL_TIM_IC_Init" in main.c inside timer2_init for low level intializations
void HAL_TIM_IC_MspInit(TIM_HandleTypeDef *htim)
{
	 GPIO_InitTypeDef tim2ch1_gpio; // creating a GPIO init type structure


	 //1. enable the peripheral clock for the timer2 peripheral
	 __HAL_RCC_TIM2_CLK_ENABLE(); //enable clock for TIM2 peripheral
	 __HAL_RCC_GPIOA_CLK_ENABLE(); //enable clock for GPIOA as we are using it as input

	  //2. Configure a gpio to behave as timer2 channel 1 as we want the channel to assign to a GPIO pin to behave as timer
	 //using it as a channel but we didn't define whether it will be a input channel or output channel
    //using pin PA0 as the alternate functionality pin as from data sheet it can be used as tim2 channel1
	 //as we want the input signal fed to the input channel must be given to a GPIO pin


	 tim2ch1_gpio.Pin = GPIO_PIN_0;//i.e.PA0
	 tim2ch1_gpio.Mode = GPIO_MODE_AF_PP;//using alternate functionality mode stm32f4xx_hal_gpio.h
	 tim2ch1_gpio.Alternate = GPIO_AF1_TIM2; //from stm32f4xx_hal_gpio_ex.h-->as we are using alternate function1 and it is for tim1
	 HAL_GPIO_Init(GPIOA,&tim2ch1_gpio);//to intialize the GPIO


	 //3. nvic settings
	 HAL_NVIC_SetPriority(TIM2_IRQn,15,0);//first set the priority settings
	 HAL_NVIC_EnableIRQ(TIM2_IRQn);//enable interrupt for that IRQ


}
//HAL_TIM_Base_Init--.calls this mspinit api hence we do low level intializations here
void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *htimer)
{

	//1. enable the clock for the TIM6 peripheral
	__HAL_RCC_TIM6_CLK_ENABLE();

	//2. Enable the IRQ of TIM6
	HAL_NVIC_EnableIRQ(TIM6_DAC_IRQn);

	//3. setup the priority for TIM6_DAC_IRQn
	HAL_NVIC_SetPriority(TIM6_DAC_IRQn,15,0);

}


void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
	 GPIO_InitTypeDef gpio_uart;
	 //here we are going to do the low level inits. of the USART2 peripheral

	 //1. enable the clock for the USART2 peripheral as well as for GPIOA peripheral
	 __HAL_RCC_USART2_CLK_ENABLE();
	 __HAL_RCC_GPIOA_CLK_ENABLE();

	 //2 . Do the pin muxing configurations
	 gpio_uart.Pin = GPIO_PIN_2;
	 gpio_uart.Mode =GPIO_MODE_AF_PP;
	 gpio_uart.Pull = GPIO_PULLUP;
	 gpio_uart.Speed = GPIO_SPEED_FREQ_LOW;
	 gpio_uart.Alternate =  GPIO_AF7_USART2; //UART2_TX
	 HAL_GPIO_Init(GPIOA,&gpio_uart);

	 gpio_uart.Pin = GPIO_PIN_3; //UART2_RX
	 HAL_GPIO_Init(GPIOA,&gpio_uart);
	 //3 . Enable the IRQ and set up the priority (NVIC settings )
	 HAL_NVIC_EnableIRQ(USART2_IRQn);
	 HAL_NVIC_SetPriority(USART2_IRQn,15,0);

}
