/*
 *
 msp.c



 *
 *  Created on: 06-Jun-2021
 *      Author: Apoorv singh negi
 */

#include "main.h"
void HAL_MspInit(void)
{
	 //Here will do low level processor specific inits.
		//1. Set up the priority grouping of the arm cortex mx processor
		HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);//by default it would be set to 4, which has subpriority as zero

		//2. Enable the required system exceptions of the arm cortex mx processor
		SCB->SHCSR |= 0x7 << 16; //usage fault, memory fault and bus fault system exceptions enabled using system handle
		                        // control and state register

		//3. configure the priority for the system exceptions, //by default=0 i.e. highest
		//to configure check hal_cortex.c file as priority group is 4 so we have last argument in each case as 0.
		HAL_NVIC_SetPriority(MemoryManagement_IRQn,0,0);
		HAL_NVIC_SetPriority(BusFault_IRQn,0,0);
		HAL_NVIC_SetPriority(UsageFault_IRQn,0,0);

}
//HAL_TIM_Base_Init--.calls this mspinit api hence we do low level intializations here
void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *htimer)
{
    //low level intializations for timer peripheral
	//1. enable the clock for the TIM6 peripheral
	__HAL_RCC_TIM6_CLK_ENABLE();

	//2. Enable the IRQ of TIM6 to get interrupts
	HAL_NVIC_EnableIRQ(TIM6_DAC_IRQn);

	//3. setup the priority for TIM6_DAC_IRQn
	HAL_NVIC_SetPriority(TIM6_DAC_IRQn,15,0); //last argument is sub-priority which is always zero as we are using priority group4
	                                          //15 is the lowest priority
	                                         //4 bits for pre-emption prioriy i.e. 0 to 2^4-1=15

}
