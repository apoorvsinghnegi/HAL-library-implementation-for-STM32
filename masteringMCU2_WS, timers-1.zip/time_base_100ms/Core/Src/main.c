//toggling LED for every 100 ms
#include<string.h>
#include "stm32f4xx_hal.h"
#include "main.h"

void SystemClockConfig(void);
void TIMER6_Init(void);
void GPIO_Init(void);
void Error_handler(void);

TIM_HandleTypeDef htimer6;


int main(void)
{
	HAL_Init();
	SystemClockConfig();
	GPIO_Init();
	TIMER6_Init();
	__HAL_RCC_BKPSRAM_CLK_ENABLE();
	__HAL_RCC_PWR_CLK_ENABLE();
	HAL_PWR_EnableBkUpAccess();
	//Lets start timer using polling mode--> timer would start counting
	HAL_TIM_Base_Start(&htimer6);

	while(1)
	{
		//when reaches our period value it rolls back to 0 and upadte event would be triggered
		//hence we toggle LED for every update time event by checking status register of timer
		//if update event will be happened it would occur in status register

		/* Loop until the update event flag is set */
		while( ! (TIM6->SR & TIM_SR_UIF) );    //TIM_SR_UIF == 1 << 0 in timer status register
		/* The required time delay has been elapsed  i.e. 100ms ke baad it would be set as it has reached the value in ARR register*/
		/* User code can be executed */
		TIM6->SR = 0;//we have to clear the status register as it is mentioned in the data sheet
		HAL_GPIO_TogglePin(GPIOA,GPIO_PIN_5);

	}


	return 0;
}


void SystemClockConfig(void)
{


}


void GPIO_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();// enble the clock for GPIOA before using it.
	GPIO_InitTypeDef ledgpio; // to toggle LED we need GPIO intialization which is PA5 for our case.
	ledgpio.Pin = GPIO_PIN_5;
	ledgpio.Mode = GPIO_MODE_OUTPUT_PP;//as we will use internal pull up register, for open drain we require external pull up register
	ledgpio.Pull = GPIO_NOPULL;//default condition
	HAL_GPIO_Init(GPIOA,&ledgpio);//(first is GPIO port address, address of the structure)
}

//as we want time base of 100 ms
void TIMER6_Init(void)
{  //basic timer is always upcounting so there is no need to intialize it
	htimer6.Instance = TIM6;//base address of timer
	htimer6.Init.Prescaler = 24;//prescaler value to divide to get 100ms time base
	htimer6.Init.Period = 64000-1;//after calculating using presclaer value of 24 we get this
	if( HAL_TIM_Base_Init(&htimer6) != HAL_OK )//to intialize the timer base unit
	{
		Error_handler();
	}

}


void Error_handler(void)
{
	while(1);
}
