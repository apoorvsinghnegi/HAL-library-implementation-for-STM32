/*
 *
 it.
c
 *
 *  Created on: 06-Jun-2021
 *      Author: Apoorv singh negi
 */
#include "main.h"

extern TIM_HandleTypeDef htimer6;
void SysTick_Handler (void)
{
	HAL_IncTick();
	HAL_SYSTICK_IRQHandler();
}

//when update events happen , interrupt would trigger and IRQ handler of interrupt would be called.

void TIM6_DAC_IRQHandler(void)  //to handle the timer interrupt generated
{
	HAL_TIM_IRQHandler(&htimer6);// to process the interrupt we have an inbuilt API so call it
	//this tells us why that interrupt happened, i.e. due to which event it happened
}
