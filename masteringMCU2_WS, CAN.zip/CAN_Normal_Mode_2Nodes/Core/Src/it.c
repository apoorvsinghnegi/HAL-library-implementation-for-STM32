/*
 *
it.c
 *
 *  Created on: 29-Jun-2021
 *      Author: Apoorv singh negi
 */


#include "main.h"

extern CAN_HandleTypeDef hcan1;
extern TIM_HandleTypeDef htimer6;



void SysTick_Handler (void)
{
	HAL_IncTick();
	HAL_SYSTICK_IRQHandler();
}


void CAN1_TX_IRQHandler(void)
{
	HAL_CAN_IRQHandler(&hcan1);
}

void CAN1_RX0_IRQHandler(void)
{
	HAL_CAN_IRQHandler(&hcan1);

}

void CAN1_SCE_IRQHandler(void)
{
	HAL_CAN_IRQHandler(&hcan1);
}

//timer 6 IRQ HANDLER
void TIM6_DAC_IRQHandler(void)
{
	HAL_TIM_IRQHandler(&htimer6);

}

//interrupt handler for button as we have button connected to pin13 of our micro-controller
//so to handle the interrupts on that pin we have to use this line
void EXTI15_10_IRQHandler(void)
{
	HAL_TIM_Base_Start_IT(&htimer6);//when button is triggered we start the timer
	HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_13);//GPIO interrupt processing API

}
