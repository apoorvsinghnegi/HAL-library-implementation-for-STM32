/*
 *
it.c
 *
 *  Created on: 25-Jun-2021
 *      Author: Apoorv singh negi
 */


#include "main.h"


extern CAN_HandleTypeDef hcan1;

void SysTick_Handler (void)
{
	HAL_IncTick();
	HAL_SYSTICK_IRQHandler();
}

//we define 4 interrupt handler, one for each IRQ and we take the name of each IRQ from the startup file
void CAN1_TX_IRQHandler(void)
{
	HAL_CAN_IRQHandler(&hcan1);//peripheral to process the interrupt

}

void CAN1_RX0_IRQHandler(void)
{
	HAL_CAN_IRQHandler(&hcan1);//peripheral to process the interrupt

}

void CAN1_RX1_IRQHandler(void)
{
	HAL_CAN_IRQHandler(&hcan1);//peripheral to process the interrupt

}

void CAN1_SCE_IRQHandler(void)
{
	HAL_CAN_IRQHandler(&hcan1);//peripheral to process the interrupt

}

