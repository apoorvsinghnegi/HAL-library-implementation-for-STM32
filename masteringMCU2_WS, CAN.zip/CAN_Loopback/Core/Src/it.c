/*
 * it.c
 *
 *  Created on: 25-Jun-2021
 *      Author: Apoorv singh negi
 */


#include "main.h"


void SysTick_Handler (void)
{
	HAL_IncTick();
	HAL_SYSTICK_IRQHandler();
}


